from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,  StructField, IntegerType, StringType, DoubleType,TimestampType
from pyspark.sql.functions import *
import json

spark = SparkSession.builder.appName('retaildata').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")


# define the schema of a single order
jsonSchema=StructType([
    StructField("invoice_no",StringType()),
    StructField("country",StringType()),
    StructField("timestamp",TimestampType()),
    StructField("type",StringType()),
    StructField("items",StringType())])


# Reading Input Data from Kafka
# Details of the Kafka broker are as follows:

# Bootstrap Server - 18.211.252.152
# Port - 9092
# Topic - real-time-project
host = sys.argv[1]
port = sys.argv[2]
topic = sys.argv[3]
dfraw = spark.\
    readStream.\
    format("kafka").\
    option("kafka.bootstrap.servers", host + ":" + port).\
    option("subscribe", topic).\
    option("includeHeaders","true").\
    load()


dfraw= dfraw.select("value")
dfraw= dfraw.withColumn("values", col("value").cast("string"))
dfraw = dfraw.select(from_json(col('values'), jsonSchema).alias("temp")).select("temp.*")

# create UDF functions
def get_is_return(type):
    if type == "RETURN":
        return 1
    return 0

def get_is_order(type):
    if type == "ORDER":
        return 1
    return 0

def get_total_cost(items):
    items = json.loads(items)
    total_cost = 0
    for item in items:
        total_cost += item["unit_price"] * item["quantity"]
    return total_cost

def get_total_items(items):
    items = json.loads(items)
    total_items = 0
    for item in items:
        total_items += item["quantity"]
    return total_items


# Converting function to UDF
is_return_UDF = udf(lambda t: get_is_return(t), IntegerType())
is_order_UDF = udf(lambda t: get_is_order(t), IntegerType())
total_cost_UDF = udf(lambda t: get_total_cost(t), DoubleType())
total_items_UDF = udf(lambda t: get_total_items(t), IntegerType())

#Calculating additional columns
dfraw = dfraw
dfraw = dfraw.withColumn("total_cost", total_cost_UDF("items"))
dfraw = dfraw.withColumn("total_items", total_items_UDF("items"))
dfraw = dfraw.withColumn("is_order", is_order_UDF("type")) 
dfraw = dfraw.withColumn("is_return", is_return_UDF("type"))

# The return cost is treated as a loss. Thus, for return orders, this value will be negative
dfraw = dfraw.withColumn("total_cost", when(dfraw.is_order == 1, dfraw.total_cost).otherwise(-dfraw.total_cost))

dfraw=dfraw.select(['invoice_no', 'country', 'timestamp', 'type' , 'total_cost', 'total_items', 'is_order', 'is_return'])

# Calculating time-based KPIs:
# Code to calculate time-based KPIs tumbling window of one minute on orders across the globe.
#KPIs have to be calculated for a 10-minute interval for evaluation; so, ten 1-minute window batches have to be taken.
dfraw_time = dfraw\
    .withWatermark("timestamp", "1 minute")\
    .groupBy( window("timestamp","1 minute"))\
    .agg(round(sum("total_cost"), 2).alias("total_sales_volume"), \
        count("invoice_no").alias("OPM"), \
        round(sum("is_return") / (sum("is_order") + sum("is_return")), 2).alias("rate_of_return"), \
        round(sum("total_cost") / count("invoice_no"), 2).alias("average_transaction_size"))

# Calculating time- and country-based KPIs
# Code to calculate time- and country-based KPIs tumbling window of one minute on orders on a per-country basis.
dfraw_time_country = dfraw\
    .withWatermark("timestamp", "1 minute")\
    .groupBy( window("timestamp","1 minute"),  "country")\
    .agg(round(sum("total_cost"), 2).alias("total_sales_volume"), \
        count("invoice_no").alias("OPM"), \
        round(sum("is_return") / (sum("is_order") + sum("is_return")), 2).alias("rate_of_return"), \
        round(sum("total_cost") / count("invoice_no"), 2).alias("average_transaction_size"))


#writing the Summarised Input table to the Console

output1 = dfraw \
      .writeStream \
    .format("console") \
    .outputMode("Append")\
    .option("truncate", "false") \
    .trigger(processingTime="1 minute") \
    .start()


# Writing KPIs to JSON Files
# Code to write the KPIs calculated above into JSON files for each one-minute window.
# These have to be written for a 10-minute interval.
 
output2 = dfraw_time.writeStream \
         .format("json") \
         .outputMode("append") \
         .option("truncate", "false") \
         .option("path", "time-wise-kpi") \
         .option("checkpointLocation", "cp-time-wise-kpi") \
         .trigger(processingTime="1 minute") \
         .start()

output3 = dfraw_time_country.writeStream \
        .format("json") \
        .outputMode("append") \
        .option("truncate", "false") \
        .option("path", "time-countrywise-kpi") \
        .option("checkpointLocation", "cp-time-countrywise-kpi") \
        .trigger(processingTime="1 minute") \
        .start()


output1.awaitTermination()
# output2.awaitTermination()
# output3.awaitTermination()






#spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.5
